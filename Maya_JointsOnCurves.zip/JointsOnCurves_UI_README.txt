Instructions :
--------------
NOTE : if you update from a previous version of this script, make sure to delete the automatically generated Compiled Python (.pyc) file, if there is one

Put the python (.py) file into your scripts folder
OR in the script editor : file/source script
then run the command :

import JointsOnCurves_UI
JointsOnCurves_UI.UI_JointsOnCurves()

---------------------------------------------------

The script has been written and tested in Maya 2019
It creates joints on curves components, or joints/joints chains along curves.
It works with NURBS curves.
It also works with Bezier curves, except in Uniform mode (the script uses Rebuild Curve, that only works with NURBS curves).

-----------------------------------------------------------------------------------------------------------------------------

Parameters work as follows :

Joints on Components :
CVs button will create joints at CVs of selected curve(s)
EPs button will create joints at EPs of selected curve(s)

Joints on Curves:
Uniform not ticked means that the script will create the specified number of joints along selected curve(s) according to its(their) parameter range(s), and tend to distribute an even number of joints on each span. The distance between resulting joints will not be uniform.
Uniform ticked means that the script will create the specified number of joints along curve(s) with even distance between them.

Chain mode will create a Joint Chain on each selected curve. If disabled, each joint will be individual.
If ticked, it will enable Orient mode, and if not, it will disable it.

Note : Orient mode only works if Chain is enabled.
Orient not ticked means that each joint of the chain will be oriented to the world
Orient ticked will reorient joints, according to maya's defaults parameters

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Update :
Text scroll lists has been replaced by checkboxes
Now returns a warning if nothing is selected