Instructions :
--------------
Put the python file into your scripts folder
OR in the script editor : file/source script
then run the command :

import JointsOnCurves_UI
JointsOnCurves_UI.UI_JointsOnCurves()

---------------------------------------------------

The script has been written and tested in Maya 2019
It creates joints on curves components, or joints/joints chains along curves.
It works with NURBS curves.
It also works with Bezier curves, except in Uniform mode (the script uses Rebuild Curve, that only works with NURBS curves).

-----------------------------------------------------------------------------------------------------------------------------

Parameters work as follows :

Joints on Components :
CVs button will create joints at CVs of selected curve(s)
EPs button will create joints at EPs of selected curve(s)

Joints on Curves:
Uniform False means that the script will create the specified number of joints along selected curve(s) according to its(their) parameter range(s), and tend to distribute an even number of joints on each span. The distance between resulting joints will not be uniform.
Uniform True means that the script will create the specified number of joints along curve(s) with even distance between them.

Chain mode will create a Joint Chain on each selected curve. If disabled, each joint will be individual.
Double Clic on True value will enable Orient mode, and Double Clic on False will disable it.

Note : Orient mode only works if Chain is True. Orient mode might be clic-able if Chain is set to False by a single clic, but will have no effect.
Orient False means that each joint of the chain will be oriented to the world
Orient True will reorient joints, according to maya's defaults parameters