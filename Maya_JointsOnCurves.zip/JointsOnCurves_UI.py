###################################
###---Create Joints On Curves---###
###################################
###---Author : Quentin Garaud---###
###################################
###---Created on Maya 2019---###
################################
###---Date : May 2020---###
###########################

#--------------------------Instructions--------------------------#
#  Put this file into your scripts folder                        #
#  OR in the script editor : file/source script                  #
#  then run the command :                                        #
#                                                                #
#  import JointsOnCurves_UI                                      #
#  JointsOnCurves_UI.UI_JointsOnCurves()                         #
#                                                                #
##################################################################

import maya.cmds as cmds

#####################
#---Joints On CVs---#
#####################
def JntOnCVs(*args):
    
    sel=cmds.ls(selection=True)
    Len=len(sel)
    
    if not sel:
        cmds.warning("Please select at least one curve")
    for j in range(0,Len):
        DEGREE = cmds.getAttr(sel[j]+'.degree')
        SPANS = cmds.getAttr(sel[j]+'.spans')
        CVS = DEGREE + SPANS
        
        for i in range(0,CVS):
            #Get Cv World Position
            PP = cmds.pointPosition(sel[j]+'.cv['+str(i)+']')
            print j,i,PP
            #Deselect To Avoid Creation Under Previous Selection
            cmds.select(d=True)
            #Create Joint at Cv World Position
            cmds.joint(n="joint_"+sel[j]+"_cv_"+str(i), p=(PP[0],PP[1],PP[2]))
#-------------------#

#####################
#---Joints On EPs---#
#####################
def JntOnEPs(*args):
    
    sel=cmds.ls(selection=True)
    Len=len(sel)
    
    if not sel:
        cmds.warning("Please select at least one curve")
    for j in range(0,Len):
        SPANS = cmds.getAttr(sel[j]+'.spans')
        EPS = SPANS +1
        
        for i in range(0,EPS):
            #Get Ep World Position
            PP = cmds.pointPosition(sel[j]+'.ep['+str(i)+']')
            print j,i,PP
            #Deselect To Avoid Creation Under Previous Selection
            cmds.select(d=True)
            #Create Joint at Ep World Position
            cmds.joint(n="joint_"+sel[j]+"_ep_"+str(i), p=(PP[0],PP[1],PP[2]))
#-------------------#

########################
#---Joints On Curves---#
########################
def JntOnCRVs(*args):
    
    sel=cmds.ls(selection=True)
    Len=len(sel)
    #Query values from UI
    NumberOfJoints = cmds.intFieldGrp('QUERYnumber', q=True, value1=True)
    IsChain = cmds.checkBox('QUERYchain', q=True, v=True)
    JntOrient = cmds.checkBox('QUERYorient', q=True, v=True)
    IsUniform = cmds.checkBox('QUERYuniform', q=True, v=True)
    
    if not sel:
        cmds.warning("Please select at least one curve")
    for j in range(0,Len):
        if IsUniform == False:
            crvMIN = cmds.getAttr(sel[j]+'.minValue')
            crvMAX = cmds.getAttr(sel[j]+'.maxValue')
        if IsUniform == True:
            DEG = cmds.getAttr(sel[j]+'.degree')
            NbSpans = NumberOfJoints-1
            cmds.rebuildCurve(sel[j], n=sel[j]+'_tmpRebuilt', constructionHistory=False, replaceOriginal=False, rebuildType=0, end=True, keepRange=0, keepControlPoints=False, keepEndPoints=True, keepTangents=False, spans=NbSpans, degree=DEG)
            crvMIN = cmds.getAttr(sel[j]+'_tmpRebuilt'+'.minValue')
            crvMAX = cmds.getAttr(sel[j]+'_tmpRebuilt'+'.maxValue')
        Urange = crvMAX-crvMIN
        if IsChain == True:
            cmds.select(d=True)
        for i in range(0,NumberOfJoints):
            JntU = (i)*Urange/(NumberOfJoints-1)
            if IsUniform == False:
                PP = cmds.pointPosition(sel[j]+'.u['+str(JntU)+']')
            if IsUniform == True:
                PP = cmds.pointPosition(sel[j]+'_tmpRebuilt'+'.u['+str(JntU)+']')
            if IsChain == False:
                cmds.select(d=True)
            cmds.joint(n="joint_"+sel[j]+"_u_"+str(i), p=(PP[0],PP[1],PP[2]))
        if IsUniform == True:
            cmds.delete(sel[j]+'_tmpRebuilt')
        if IsChain and JntOrient:
            cmds.joint("joint_"+sel[j]+"_u_0", e=True, orientJoint='xyz', secondaryAxisOrient='yup', children=True, zeroScaleOrient=True)

#-------------------#

#####################
#---Create Window---#
#####################

### Defines the command to en/dis-able the Orient entry
def triggerOrientUI(*args):
    TriggerIsChain = cmds.checkBox('QUERYchain', q=True, v=True)
    if TriggerIsChain == True:
        cmds.checkBox('QUERYorient', edit=True, enable=True)
    else :
        cmds.checkBox('QUERYorient', edit=True, enable=False)


### Create Window
def UI_JointsOnCurves(*args):
    windowName='JointsOnCurves'
    #Delete UI if already loaded
    if cmds.window(windowName, exists=True):
        cmds.deleteUI(windowName)
    
    #---CREATE WINDOW---#
    JntOnCrvWindow = cmds.window(windowName, title=windowName, iconName='JntOnCrv', widthHeight=(280, 220))
    mainRow = cmds.rowLayout(numberOfColumns=3)
    #'On Components' Column
    mainColA = cmds.columnLayout( adjustableColumn=True, parent=mainRow)
    cmds.text( label='Joints on Components', font='boldLabelFont', height=50 )
    cmds.button( label='CVs', height=30, command=JntOnCVs)
    cmds.button( label='EPs', height=30, command=JntOnEPs)
    #Separator
    mainColSep = cmds.columnLayout( adjustableColumn=True, parent=mainRow)
    cmds.separator( hr=False, width=20, height=200, style='in' )
    #'On Curves' Column
    mainColB = cmds.columnLayout( adjustableColumn=True, parent=mainRow)
    cmds.text( label='Joints on Curves', font='boldLabelFont', height=50 )
    cmds.checkBox('QUERYuniform', label='Uniform (NURBS only)', value=False, parent=mainColB)
    subRowB = cmds.rowLayout(numberOfColumns=2, parent=mainColB)
    cmds.text( label='Number', parent=subRowB)
    cmds.intFieldGrp('QUERYnumber', numberOfFields=1, value1=10, parent=subRowB)
    cmds.checkBox('QUERYchain', label='Chain', changeCommand = triggerOrientUI, value=False, parent=mainColB)
    cmds.checkBox('QUERYorient', label='Orient', value=False, enable=False, parent=mainColB)
    cmds.button( label='Create', parent=mainColB, command=JntOnCRVs)
    cmds.showWindow(JntOnCrvWindow)
